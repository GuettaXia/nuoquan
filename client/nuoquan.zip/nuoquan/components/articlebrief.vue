<template>
	<view class="articlecard">
		<view class="title">{{ articlecontent[1] }}</view>
		<view class="briefarticlecontent">{{ articlecontent[2] }}</view>
		<view class="picturearea">
			<image src="../../static/0001/pic1.jpg" v-if="articlecontent[3]"></image>
			<image src="../../static/0001/pic2.jpg" v-if="articlecontent[4]"></image>
			<image src="../../static/0001/pic3.jpg" v-if="articlecontent[5]"></image>
		</view>
		<view class="menubar">
			<image src="../../static/touxiang.jpg" class="touxiang"></image>
			<view class="name">{{ articlecontent[6] }}</view>
			<view class="time">{{ articlecontent[7] }}</view>
			<view class="icons">
				<image class="share" src="../../static/icon/分享.svg"></image>
				<image class="comment" src="../../static/icon/评论.svg"></image>
				<image class="like" src="../../static/icon/点赞.svg"></image>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	name: 'aticlebrief',
	props: {
		articlecontent: {
			type: Array
		}
	},
	data() {
		return {};
	},
	methods: {},
	created: function() {
		console.log('777');

		console.log(this.articlecontent);
	}
};
</script>

<style>
.articlecard {
	margin: 30px 4px;
	border-radius: 30px;
	background-color: #e4e4e4;
	padding: 15px 10px;
}

.title {
	font-size: 18px;
	padding-bottom: 10px;
}
.briefarticlecontent {
	font-size: 14px;
}
.menubar {
	height: 35px;
	vertical-align: middle;
}
.touxiang {
	border-border-radius: 30px;
	width: 20px;
	height: 20px;
	margin-right: 5px;
	vertical-align: middle;
}
.name {
	display: inline-block;
	width: 60px;
	left: 40px;
	font-size: 14px;
}
.time {
	display: inline-block;
	left: 120px;
	font-size: 14px;
}
.icons {
	width: 160px;
	text-align: right;
	display: inline-block;
	content-flex: right;
}
.icons image {
	width: 15px;
	height: 15px;
	padding-right: 10px;
}
.picturearea {
	margin: auto;
	display: flex;
	justify-content: center;
}

image {
	width: 30%;
	height: 200upx;
	margin: auto;
}
</style>
