<template>
	<view >
		<view class="title">
		{{articlecontent[1]}}		
		</view>
		<view class="briefarticlecontent">
		{{articlecontent[2]}}
		</view>
		<view class="picturearea">
			<image src="../../static/'articlecontent[0]/articlecontent[3]'"></image>
			<image src="../../static/'articlecontent[0]/articlecontent[4]'"></image>
			<image src="../../static/'articlecontent[0]/articlecontent[5]'"></image>
			
		</view>
		<view class="menubar">
			
		</view>
	</view>
</template>

<script>
	export default {
		name:'aticlebrief',
		props:{
			articlecontent:{
				type:Array,
			},
		},
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		created:function(){
									console.log("777");
			
						console.log(this.articlecontent);
				
			
		}
	}
</script>

<style>

</style>
