<template>
	<view>123</view>
</template>

<script>
	export default{
		name:'son',
		
	}
</script>

